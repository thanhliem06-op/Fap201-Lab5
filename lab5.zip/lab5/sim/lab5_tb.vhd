
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity lab5_tb is
end entity lab5_tb;

architecture SIM of lab5_tb is

    constant CLK_PERIOD : time := 20 ns;

    signal i_Clk      : STD_LOGIC := '0';
    signal i_Rst      : STD_LOGIC := '0';
    signal i_Switch_1 : STD_LOGIC := '0';
    signal i_Switch_2 : STD_LOGIC := '0';

    signal o_LED_1 : STD_LOGIC;
    signal o_LED_2 : STD_LOGIC;
    signal o_LED_3 : STD_LOGIC;
    signal o_LED_4 : STD_LOGIC;

begin

    i_Clk <= not i_Clk after CLK_PERIOD / 2;

    DUT: entity work.lab5
        generic map (
            G_LFSR_WIDTH => 3
        )
        port map (
            i_Clk      => i_Clk,
            i_Rst      => i_Rst,
            i_Switch_1 => i_Switch_1,
            i_Switch_2 => i_Switch_2,
            o_LED_1    => o_LED_1,
            o_LED_2    => o_LED_2,
            o_LED_3    => o_LED_3,
            o_LED_4    => o_LED_4
        );

    process
    begin
        -- Reset
        i_Rst <= '0';
        wait for 4 * CLK_PERIOD;
        i_Rst <= '1';

        -- Test all switch combinations
        i_Switch_2 <= '0';
        i_Switch_1 <= '0';
        wait for 500 ns;

        i_Switch_2 <= '0';
        i_Switch_1 <= '1';
        wait for 500 ns;

        i_Switch_2 <= '1';
        i_Switch_1 <= '0';
        wait for 500 ns;

        i_Switch_2 <= '1';
        i_Switch_1 <= '1';
        wait for 500 ns;

        report "LAB5 TESTBENCH FINISHED" severity note;
        wait;
    end process;

end architecture SIM;
