
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity lfsr_timer is
    generic (
        G_LFSR_WIDTH : positive := 22
    );
    port (
        i_Clk  : in  STD_LOGIC;
        i_Rst  : in  STD_LOGIC;
        o_Done : out STD_LOGIC
    );
end entity lfsr_timer;

architecture TIMER_RTL of lfsr_timer is

    constant C_SEED : STD_LOGIC_VECTOR(G_LFSR_WIDTH-1 downto 0)
        := (0 => '1', others => '0');

    signal r_LFSR : STD_LOGIC_VECTOR(G_LFSR_WIDTH-1 downto 0)
        := C_SEED;

    signal w_Feedback : STD_LOGIC;

begin

    -- Feedback for 3-bit LFSR
    gen_width_3 : if G_LFSR_WIDTH = 3 generate
        w_Feedback <= r_LFSR(2) xor r_LFSR(0);
    end generate;

    -- Feedback for 22-bit LFSR
    gen_width_22 : if G_LFSR_WIDTH = 22 generate
        w_Feedback <= r_LFSR(21) xor r_LFSR(0);
    end generate;

    process(i_Clk)
        variable v_Next :
            STD_LOGIC_VECTOR(G_LFSR_WIDTH-1 downto 0);
    begin
        if rising_edge(i_Clk) then
            if i_Rst = '0' then
                r_LFSR <= C_SEED;
                o_Done <= '0';
            else
                v_Next :=
                    r_LFSR(G_LFSR_WIDTH-2 downto 0) & w_Feedback;

                r_LFSR <= v_Next;

                if v_Next = C_SEED then
                    o_Done <= '1';
                else
                    o_Done <= '0';
                end if;
            end if;
        end if;
    end process;

end architecture TIMER_RTL;
