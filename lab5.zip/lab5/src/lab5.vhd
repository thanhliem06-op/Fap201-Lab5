
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity lab5 is
    generic (
        G_LFSR_WIDTH : positive := 22
    );
    port (
        i_Clk      : in  STD_LOGIC;
        i_Rst      : in  STD_LOGIC;
        i_Switch_1 : in  STD_LOGIC;
        i_Switch_2 : in  STD_LOGIC;
        o_LED_1    : out STD_LOGIC;
        o_LED_2    : out STD_LOGIC;
        o_LED_3    : out STD_LOGIC;
        o_LED_4    : out STD_LOGIC
    );
end entity lab5;

architecture RTL of lab5 is

    signal w_Done  : STD_LOGIC := '0';
    signal r_Blink : STD_LOGIC := '0';

begin

    TIMER: entity work.lfsr_timer
        generic map (
            G_LFSR_WIDTH => G_LFSR_WIDTH
        )
        port map (
            i_Clk  => i_Clk,
            i_Rst  => i_Rst,
            o_Done => w_Done
        );

    process(i_Clk)
    begin
        if rising_edge(i_Clk) then
            if i_Rst = '0' then
                r_Blink <= '0';
            elsif w_Done = '1' then
                r_Blink <= not r_Blink;
            end if;
        end if;
    end process;

    process(r_Blink, i_Switch_1, i_Switch_2)
        variable v_Sel : STD_LOGIC_VECTOR(1 downto 0);
    begin
        o_LED_1 <= '0';
        o_LED_2 <= '0';
        o_LED_3 <= '0';
        o_LED_4 <= '0';

        v_Sel := i_Switch_2 & i_Switch_1;

        case v_Sel is
            when "00" => o_LED_1 <= r_Blink;
            when "01" => o_LED_2 <= r_Blink;
            when "10" => o_LED_3 <= r_Blink;
            when "11" => o_LED_4 <= r_Blink;
            when others => null;
        end case;
    end process;

end architecture RTL;
